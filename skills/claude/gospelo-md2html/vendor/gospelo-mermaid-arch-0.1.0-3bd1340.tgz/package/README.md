# mermaid-arch

> mermaid-arch: Architecture diagrams in Mermaid, with icon packs (AWS and more) and ELK layout.

<p align="center"><img src="docs/patterns.gif" alt="Architecture patterns drawn with mermaid-arch" width="840"></p>

This is not an official Mermaid project. It is maintained by gospelo-dev and
is meant for gospelo-mermaid-plus and gospelo-md2html.

- Mermaid is a dependency, not part of this package: `"mermaid": "12.3.0"`
  (exact version). The renderer uses the official `dist/mermaid.min.js` of
  the installed package. `src/mermaid-manifest.json` records the version,
  tarball URL, npm integrity and the sha256 of each file used; before
  drawing, the installed package is checked against it, and a missing
  package, another version or a changed file stops with an error that says
  how to fix it (`npm ci`, or `npm install --save-exact mermaid@12.3.0`).
  `mermaid.min.js` bundles elkjs (EPL-2.0); keeping it out of this package
  lets projects commit the mermaid-arch tarball without carrying elkjs.
- `vendor/fontawesome/<version>/` -- Font Awesome Free 6 from the npm
  tarball, unchanged: `css/all.min.css`, its woff2 fonts and `LICENSE.txt`
  (icons CC BY 4.0, fonts SIL OFL 1.1, code MIT), with a `MANIFEST.json`
  that records the version, tarball URL, npm integrity and sha256 of each
  file. Used only when `fontAwesome: true` is given.
- `src/mermaid-arch.js` -- a small browser helper that registers icon packs
  and calls `mermaid.initialize`. It does not contain Mermaid.
- `src/*.ts` -- the library and the `mermaid-arch` CLI (TypeScript, built
  into `dist/` with `tsc`): icon packs from the AWS icon zip, and rendering
  to PNG / SVG in chrome-headless-shell.

Mermaid 12 bundles the ELK layout in `mermaid.min.js` and shares one icon
registry between the core renderer and ELK, so `@mermaid-js/layout-elk` is
not needed. (With Mermaid 11.x + layout-elk, ELK kept its own registry and
icon nodes in `layout: elk` diagrams rendered as the "?" unknown icon.)

Requires Node.js 22.12 or later. Development uses Node 26.13.0 (`.nvmrc`).

## Use in a page

```html
<script src="mermaid.min.js"></script>
<script src="mermaid-arch.js"></script>
<script>
  mermaidArch.setup({ iconPacks: [awsPack], config: { theme: 'default' } })
  mermaid.run()
</script>
```

`setup` throws when `window.mermaid` is missing or a pack is malformed
(no prefix, no icons, duplicated prefix). `startOnLoad` defaults to `false`.
The helper is exported as `@gospelo/mermaid-arch/browser`.

Diagram forms covered by the tests:

```
flowchart LR
    fn@{ icon: "aws:lambda", form: "square", label: "Handler" }

architecture-beta
    service fn(aws:lambda)[Handler]
```

Note: in Mermaid 12 the default `layout` is `elk`. Set `layout: dagre`
explicitly where the previous layout is wanted.

## Render diagrams (publishing)

The AWS icons are not part of this repository. Download the Architecture
Icons asset package from https://aws.amazon.com/architecture/icons/.

The icon pack is AWS artwork. Do not commit or publish it; publish the
drawn diagrams instead, which is how AWS permits the icons to be used.
`mermaid-arch render` does this: it builds the pack from your local icon
zip, registers it in a headless page with the installed Mermaid, and writes
only the images. The pack never leaves mermaid-arch.

```sh
npx mermaid-arch render docs/architecture.md --icons-zip Icon-package_*.zip
npx mermaid-arch render docs/architecture.md --icons-zip Icon-package_*.zip \
  --format png,svg --scale 2 --max-width 1000 --out-dir docs/images
```

Each ` ```mermaid ` block becomes `<stem>-<n>.png` (and `.svg` if asked).
A `.mmd` / `.mermaid` file is one diagram. PNG is the default because it
shows the same everywhere, including GitHub; Mermaid's SVG draws text with
HTML (`foreignObject`), which some viewers do not render.

Size: each diagram is drawn at its natural size, which its content decides
(icon sizes such as flowchart `h:` or architecture `iconSize`, labels,
layout direction). `--max-width` shrinks wider diagrams; the PNG is the
resulting size times `--scale` (default 2). Shrinking scales icons and text
too, so it stops with `too-wide` when an icon that was at least
`--min-icon-size` px (default 32) would come out smaller; the error
suggests narrower layouts that it has drawn and measured, and the smallest
`--max-width` that works.

### From TypeScript / JavaScript

One browser and page are reused for every call until `close()`:

```ts
import { createRenderer, diagramsInFile } from '@gospelo/mermaid-arch'

const renderer = createRenderer({ iconsZip: 'Icon-package_07312026.zip' })
try {
  for (const file of ['docs/a.md', 'docs/b.md']) {
    const { images } = await renderer.render(diagramsInFile(file), { formats: ['png'], maxWidth: 1000 })
    // images[i].png: Uint8Array, images[i].width / height: display size in CSS px
  }
} finally {
  await renderer.close()
}
```

`renderDiagrams(diagrams, options)` renders once (launch, draw, close).
Diagrams are strings or `{ text, file, line }` objects (`diagramsInFile` and
`mermaidBlocks` return them) so that errors point at file lines.
`mermaidBlocks` also gives where each block is, for tools that replace
blocks in the Markdown: `fence: { startLine, endLine }` (1-based lines of
the opening and closing fence) and `offset: { start, end }` (UTF-16
offsets, `markdown.slice(start, end)` is the block from the opening fence
to the end of the closing fence, without its line break).

More options:

- `createRenderer({ chromeArgs: ['--no-sandbox'] })` adds browser
  command-line arguments (for containers without a usable sandbox).
- `createRenderer({ browser })` draws in a puppeteer-core `Browser` the
  caller already has, in a page of its own; `close()` closes only that
  page and the browser stays the caller's (`render()` reports `browser.source`
  as `'browser'`). It cannot be combined with `chrome` / `chromeArgs`.
  `launchBrowser({ chrome, chromeArgs })` starts chrome-headless-shell the
  way the renderer does (same search order, see
  [Browser for rendering](#browser-for-rendering)), for callers that use
  the browser for other work too.
- `createRenderer({ css })` adds CSS (a string or a list) to the drawing
  page: `@font-face` rules for the fonts the diagrams are shown in (fonts as
  `data:` URLs), or Font Awesome for `fa:` icons in labels. All declared
  font faces are loaded before the first drawing, so labels are measured
  with them; a face that does not load is a `bad-argument` error.
- `createRenderer({ fontAwesome: true })` loads the vendored Font Awesome
  Free 6 into the drawing page, so `fa:fa-user` / `fab:fa-github` icons in
  labels are drawn (without it they are blank). The SVG only refers to the
  classes and the font: a page that shows the SVG needs Font Awesome too,
  and `fontAwesome().css` gives the same CSS with the fonts inlined. PNGs
  contain the glyphs. These icons are text, not icon-pack icons, so the
  `minIconSize` check does not apply to them.
- `render(diagrams, { mermaidConfig })` passes a Mermaid configuration
  (`theme`, `themeVariables`, `securityLevel`, ...) to `mermaid.initialize`
  for this call; the next call without it is back to the defaults. Order,
  last wins: mermaid-arch's defaults (`handDrawnSeed: 1`), then
  `mermaidConfig`, then `startOnLoad: false` (always). A diagram's own
  `%%{init}%%` / front matter still overrides all of them.

  Give `fontFamily` here, not in a diagram: Mermaid checks the values of
  `%%{init}%%` / front matter and drops a `themeVariables.fontFamily` with
  commas or quotes (`"'IBM Plex Sans', 'Zen Kaku Gothic New', sans-serif"`),
  so the labels fall back to another font; a single name (`Inter`) passes.
  The fonts themselves come from `css` (`@font-face`) or the system:

  ```ts
  const renderer = createRenderer({ css: fontFaceCss })   // @font-face rules, fonts as data: URLs
  await renderer.render(diagrams, {
    mermaidConfig: { themeVariables: { fontFamily: "'IBM Plex Sans', 'Zen Kaku Gothic New', sans-serif" } },
  })
  ```
- `render(diagrams, { background: 'transparent' })` sets the PNG
  background: a CSS color or `'transparent'` (default `'white'`). SVGs have
  no background.
- `render(diagrams, { idPrefix: 'doc3-fig' })` names the diagrams'
  `<svg>` elements `doc3-fig-1`, `doc3-fig-2`, ... (default `mermaid-arch`).
  Mermaid derives its internal ids from it, and the element ids inside
  icons become `doc3-fig-1-icon-1`, ... (Iconify's random ids are
  replaced). Each diagram's SVG `<style>` is scoped by its id, so give
  different prefixes to drawings that end up in one page; mermaid-arch does
  not check for duplicates. The prefix must start with a letter and contain
  only letters, digits, `-` and `_`.
  The page draws with a fixed `handDrawnSeed`, so the same diagram with the
  same prefix always gives the same SVG.
- `iconCategories(iconsZip, { names })` returns, by icon name, the AWS
  category and the icon's background color (`{ category: 'compute', color:
  '#ED7100' }`), so that theme tools can leave icon nodes in their AWS
  category colors.

Errors are
`BuildError` with `code`, `diagnostics` and `codeActions`; `err.toJSON(tool)`
gives the JSON form (see [Errors](#errors)).

Reusing the renderer saves the browser start and the 5.5 MB Mermaid load
for every call after the first: 5 files take about 1.4 s with one renderer,
against about 4.4 s with 5 CLI runs.

### Use in other projects (tarball)

mermaid-arch is not on npm. Other projects (gospelo-mermaid-plus,
gospelo-md2html) take a tarball made with `npm pack` from a commit on
`main`, keep it in their repository and depend on it with a `file:` path.
It contains `dist/` and the vendored Font Awesome with its licenses, so it
needs no build and no access to this repository. It does not contain
Mermaid: its dependencies (`mermaid` 12.3.0, `puppeteer-core`, ...) come
from the npm registry when the other project runs `npm ci`. The other
project may depend on `"mermaid": "12.3.0"` itself as well; it must be the
same exact version.

Make it from a clean checkout of the commit, not from a working tree with
changes:

```sh
commit=f4cb484                                  # a commit on main
git worktree add --detach /tmp/mermaid-arch-$commit $commit
cd /tmp/mermaid-arch-$commit
npm ci --ignore-scripts                         # TypeScript for "prepare"
npm pack --pack-destination /tmp/mermaid-arch-pack   # "prepare" builds dist/
cd - && git worktree remove --force /tmp/mermaid-arch-$commit
```

`npm pack` names it `gospelo-mermaid-arch-<version>.tgz`. Rename it to
`gospelo-mermaid-arch-<version>-<commit>.tgz` (short commit), so that a
tarball from another commit has another path, and record next to it the
full commit, the sha256 and the npm integrity (`npm pack` prints it):

```sh
mv /tmp/mermaid-arch-pack/gospelo-mermaid-arch-0.1.0.tgz /tmp/mermaid-arch-pack/gospelo-mermaid-arch-0.1.0-$commit.tgz
shasum -a 256 /tmp/mermaid-arch-pack/gospelo-mermaid-arch-0.1.0-$commit.tgz
```

In the other project:

```json
"dependencies": { "@gospelo/mermaid-arch": "file:vendor/gospelo-mermaid-arch-0.1.0-f4cb484.tgz" }
```

`package-lock.json` records the tarball's integrity, so `npm ci` fails if
the file is changed. Import `@gospelo/mermaid-arch` (`dist/`), not files
under its `src/`. When bundling (esbuild and the like), keep
`@gospelo/mermaid-arch`, `mermaid` and `puppeteer-core` external:
mermaid-arch reads `vendor/`, `src/` (`mermaid-arch.js`,
`mermaid-manifest.json`) from its package directory and
`mermaid/dist/mermaid.min.js` from `node_modules` at run time.
`installedMermaid()` returns the version, path and checked content of the
Mermaid build it uses (`vendoredMermaid()` is kept as an alias).
chrome-headless-shell is installed separately (see
[Browser for rendering](#browser-for-rendering)).

## AWS icon pack

To use the icons in your own page (locally), build a pack:

```sh
npx mermaid-arch build-iconpack Icon-package_*.zip -o aws.json
npx mermaid-arch build-iconpack Icon-package_*.zip -o aws.json --from diagram.mmd docs/*.md
npx mermaid-arch build-iconpack Icon-package_*.zip --list
```

Names are shortened: `Arch_AWS-Lambda_48.svg` -> `lambda`,
`Arch_Amazon-API-Gateway_48.svg` -> `api-gateway`. A service that appears
under more than one category with different artwork gets the category
name appended instead (`compute-optimizer-compute`,
`compute-optimizer-management-tools`); the bare name is not created.
`--size` picks the icon size (default 48).

`--from` builds a pack with only the icons your diagrams use. It looks for
`icon: "aws:..."` (flowchart) and `(aws:...)` (architecture-beta). A
`.mmd` / `.mermaid` file is read as one diagram; in a `.md` / `.markdown`
file only the ` ```mermaid ` (or `~~~mermaid`) blocks are read, so names in
prose or other code blocks are ignored. An unknown name, an unclosed
mermaid block or another file type is an error.

## Browser for rendering

Rendering uses `puppeteer-core` with **chrome-headless-shell**.
mermaid-arch does not download a browser. Install the version
puppeteer-core expects into puppeteer's cache once; it is then found
without any setting:

```sh
npx @puppeteer/browsers install chrome-headless-shell@156.0.8078.47 --path ~/.cache/puppeteer
```

`156.0.8078.47` is the version puppeteer-core 25.16.0 expects. You do not
need to look it up: when no browser is found, rendering stops with
`chrome-missing` and prints this command with the expected version and the
cache path filled in. Without `--path`, `@puppeteer/browsers` installs into
the current directory.

The browser is taken from, in order:

1. `--chrome PATH` (`{ chrome }` in the API); a relative path is taken
   from the current directory
2. `CHROME_PATH`
3. `PUPPETEER_EXECUTABLE_PATH`
4. puppeteer's cache: `$PUPPETEER_CACHE_DIR`, or `~/.cache/puppeteer` when
   that is unset. Only chrome-headless-shell of exactly the version
   puppeteer-core expects is used; other versions there are ignored, so the
   browser does not change without notice.

An explicit setting (1-3) always wins: if it is set but is not a file,
rendering stops with `chrome-missing` instead of falling back to the cache.
The CLI prints which browser it used (`using <path> (from <source>)`), and
`render()` returns it as `browser`.

It is launched with `headless: 'shell'`. Give the chrome-headless-shell
binary. A regular Chrome also starts (checked with Chrome for Testing 156),
but it is the full browser, which is what this setup avoids; its PNGs
differ from chrome-headless-shell's only in anti-aliasing at edges (about
1% of pixels in `examples/`), with the same layout and SVG. A path that does
not start stops with `chrome-launch-failed`.

The CLI also runs on Bun (`bun dist/cli/main.js ...`), with the same output.

## Errors

Every command reports a failure with an error code, the places it is about
and concrete fixes (line edits, option changes), best first. Fixes are
generated for the situation: for example, when a diagram is too wide for
`--max-width`, the tool renders narrower layouts, measures them, and
suggests the ones that fit, with their sizes.

Add `--error-format json` to get one JSON object on stderr, for AI agents
and other tools. The format (LSP Diagnostic / CodeAction shapes with rustc
style applicability) is defined in
[docs/error-format.md](docs/error-format.md)
([Japanese](docs/error-format_ja.md)). Exit codes: 0 success, 1 error,
2 usage error.

## Development

```sh
nvm use                 # Node 26.13.0
npm ci
npx @puppeteer/browsers install chrome-headless-shell@156.0.8078.47 --path ~/.cache/puppeteer   # once
npm test                # builds dist/ with tsc, then node --test
npm run typecheck       # tsc --noEmit
```

`dist/` is not committed. The `prepare` script builds it, so it is there
after `npm ci` / `npm install` here, and when another package depends on
mermaid-arch through a git URL (npm then installs the devDependencies to
build it).

No `CHROME_PATH` is needed when the expected chrome-headless-shell is in
puppeteer's cache (see [Browser for rendering](#browser-for-rendering)).

Development tools (not published):

```sh
npm run make-example-html -- examples/serverless-orders.md --icons-zip Icon-package_*.zip --static
npm run sync-mermaid -- 12.3.0        # pin Mermaid: write src/mermaid-manifest.json
npm run sync-fontawesome -- 6.7.2     # fetch Font Awesome Free into vendor/
npm run verify:vendor                 # check node_modules/mermaid and vendor/ against the manifests
```

`make-example-html` turns the ` ```mermaid ` blocks of a Markdown file into
a sample HTML page (see `examples/`): by default Mermaid from the jsDelivr
CDN draws them in the browser with an icon pack inlined (for trying out
locally; do not publish it), and with `--static` they are drawn now and
embedded as SVG (no scripts, no CDN, no icon pack; for publishing).

To update Mermaid, run `npm run sync-mermaid -- <version>`, then
`npm install --save-exact mermaid@<version>`; the two must agree
(`verify:vendor` checks it). A Dependabot pull request that only bumps
`mermaid` fails the tests until the manifest is updated the same way. When
updating Font Awesome, remove the old `vendor/fontawesome/<old version>/`
directory; exactly one version is expected. Font Awesome stays on 6.x:
gospelo-mermaid-plus lists the FA6 Free Solid icons it allows.

### Tests

- `tests/golden.test.mjs` runs the cases in `tests/fixtures/golden/cases.json`
  with the TS CLI and compares exit codes, error JSON, text output, icon
  packs, normalized SVG / HTML and PNGs (size, and pixels up to
  anti-aliasing noise) with the outputs recorded from the Python version
  (`results.json`; see `tests/fixtures/golden/README.md`). Differences that
  come from the port itself (command names in messages, API option names)
  are listed in the test.
- `tests/unit.test.mjs` covers the library: difflib-compatible suggestions,
  file lines in errors, icon packs, and browser reuse in the renderer.
- `tests/chrome-ts.test.mjs` covers where the browser is taken from.
- `tests/render.test.mjs`, `setup.test.mjs`, `logos.test.mjs` check
  `src/mermaid-arch.js` with the installed Mermaid: icons in flowchart +
  `layout: elk`, flowchart + `layout: dagre` and `architecture-beta`, that
  ELK is really used, and the published `@iconify-json/logos` pack.

### CI and dependency updates

`.github/workflows/ci.yml` runs on pushes to `main` and on pull requests,
on Linux (ubuntu-24.04):

- Node `22.12.0` (the lowest in `engines`) and `24` must pass; `26` runs
  for reference and does not fail the run.
- `npm ci --ignore-scripts` (no package install scripts), then
  `npm audit signatures` (registry signatures and provenance).
- chrome-headless-shell of the version puppeteer-core expects, cached;
  then `npm run typecheck` and `npm test`.
- Read-only token; actions are pinned to commit SHAs.

`.github/dependabot.yml` keeps npm packages and the actions up to date.
Version updates wait for a cooldown (7 days; 14 for major versions), so a
release that turns out to be malicious or broken is usually pulled before
a pull request appears. Security updates are not delayed: with Dependabot
security updates enabled in the repository settings, a pull request is
opened as soon as an advisory has a fixed version. Minor and patch updates
are grouped into one pull request.

`.npmrc` sets `allow-git=none`: dependencies come from the npm registry
only. `min-release-age` is not set there on purpose, because it would also
block a security fix that is younger than the limit.

### Release

`.github/workflows/release.yml` publishes to npm when a tag `v<version>`
is pushed: it runs the CI tests (`ci.yml`), checks that the tag matches
`version` in `package.json`, that npm is 11.5.1 or later, the installed
Mermaid and the vendored files against their manifests, and runs `npm publish` (`prepare` builds
`dist/`).

It uses npm trusted publishing (OIDC): no npm token is kept in GitHub. On
npmjs.com the package's trusted publisher names the GitHub repository
`gospelo-dev/mermaid-arch` and the workflow `release.yml`. npm adds
provenance when the repository is public. `repository.url` in
`package.json` must stay the GitHub repository.

`"private": true` in `package.json` blocks publishing until it is removed.

```sh
npm version 0.1.0 --no-git-tag-version   # set the version, then commit
git tag v0.1.0 && git push origin v0.1.0
```

### History

mermaid-arch was first written in Python and ported to TypeScript; the
Python version was checked against the golden outputs and then removed
(it is in the history up to commit e92e97a). `src/py.ts` and
`src/difflib.ts` keep the Python formatting and "did you mean" suggestions
so that messages stay the same.
