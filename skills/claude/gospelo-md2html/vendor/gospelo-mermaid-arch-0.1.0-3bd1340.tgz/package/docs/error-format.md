# Error output format

Status: version 1 (draft)

Japanese: [error-format_ja.md](error-format_ja.md)

The mermaid-arch scripts are used by people and by AI agents. When a run
fails, the error says what went wrong, where, and how to fix it, in a form
both can act on. This document defines that form.

There is no single standard for CLI errors with fixes. This format reuses
the parts of existing formats that fit:

- **LSP** (Language Server Protocol 3.17) `Diagnostic` and `CodeAction`
  for "what is wrong, where" and "how to fix it".
- **rustc** JSON diagnostics for how sure a suggested fix is
  (`suggestion_applicability`), which LSP lacks.

SARIF 2.1.0 was considered and not used: it is built to collect many
static-analysis results, not to report why one run failed.

## Scope

Applies to:

| Command | `tool` in the JSON | Purpose |
|---|---|---|
| `mermaid-arch build-iconpack` | `build_iconpack` | build an icon pack from the AWS icon zip |
| `mermaid-arch render` | `render` | render diagrams to PNG / SVG |
| `npm run make-example-html` (development) | `make_example_html` | make sample HTML pages |
| `npm run sync-mermaid` (development) | `sync_mermaid` | pin the Mermaid version (`src/mermaid-manifest.json`) and verify the installed `mermaid` package |

and to the library API (`BuildError`, see below). A usage error before a
command is chosen (no or unknown command) is reported with `tool`
`mermaid-arch`.

## Output channels and exit codes

- Results (written file names, `--list` output) go to stdout or are
  written to files. Errors go to **stderr**.
- `--error-format text` (default) prints the text form; `--error-format
  json` prints exactly **one JSON object** followed by a newline, and
  nothing else, on stderr.
- Exit codes:

| Code | Meaning |
|---|---|
| 0 | success |
| 1 | the run failed; an error was reported |
| 2 | the command line could not be parsed (usage error); with `--error-format json` this is also reported as JSON with code `usage` |

A run stops at the first error. One error can carry several diagnostics
(for example, every line that uses an unknown icon name).

## JSON form

```json
{
  "version": 1,
  "tool": "render",
  "error": "too-wide",
  "message": "diagram 1 is 1819px wide; shrinking it to --max-width 1000 would draw 48px icons at 26px, below --min-icon-size 32.",
  "diagnostics": [ Diagnostic, ... ],
  "codeActions": [ CodeAction, ... ]
}
```

| Field | Type | Meaning |
|---|---|---|
| `version` | integer | version of this format; this document is version 1 |
| `tool` | string | script that reported the error: `build_iconpack`, `render`, `make_example_html`, `sync_mermaid` |
| `error` | string | error code (see [Error codes](#error-codes)); stable, kebab-case |
| `message` | string | what went wrong, one or more English sentences |
| `diagnostics` | array | places the error is about; may be empty (for example a missing file) |
| `codeActions` | array | ways to fix it, best first; may be empty when no fix is known |

### Diagnostic

Follows LSP `Diagnostic`, with the document identified by `file` and
`diagram` instead of a URI.

```json
{
  "file": "docs/arch.md",
  "diagram": 1,
  "range": { "start": { "line": 6, "character": 0 }, "end": { "line": 6, "character": 12 } },
  "severity": "error",
  "code": "too-wide",
  "source": "mermaid-arch",
  "message": "this diagram is laid out left to right",
  "lineText": "flowchart LR",
  "data": { "naturalWidth": 1819 }
}
```

| Field | Type | Meaning |
|---|---|---|
| `file` | string or null | path as given to the command; null when the diagram was passed as a string (library API) |
| `diagram` | integer or null | 1-based number of the diagram (` ```mermaid ` block) in the input, when the error is about one |
| `range` | Range or null | LSP Range; see [Positions](#positions). null when the error has no position in a text |
| `severity` | string | `error`, or `info` for extra places related to the error |
| `code` | string | error code, same as the top-level `error` for the main diagnostic |
| `source` | string | always `mermaid-arch` |
| `message` | string | what is wrong at this place |
| `lineText` | string | the whole text of the first line of `range` (convenience; not in LSP) |
| `data` | object | optional tool-specific details, e.g. Mermaid's own parser message under `mermaid` |

### CodeAction

Follows LSP `CodeAction` (`title`, `kind`, `isPreferred`, `edit`), plus
`applicability` from rustc and `command` / `result` for fixes that are not
text edits.

```json
{
  "title": "Change \"flowchart LR\" to \"flowchart TB\" (544px wide, icons stay 48px)",
  "kind": "quickfix",
  "isPreferred": true,
  "applicability": "maybe-incorrect",
  "diagnostics": [0],
  "edit": {
    "changes": {
      "docs/arch.md": [
        { "range": { "start": { "line": 6, "character": 0 }, "end": { "line": 6, "character": 12 } },
          "newText": "flowchart TB" }
      ]
    }
  },
  "result": { "width": 544, "height": 1879, "iconPx": 48, "fits": true }
}
```

| Field | Type | Meaning |
|---|---|---|
| `title` | string | what the fix does, one line |
| `kind` | string | `quickfix` (LSP kind) |
| `isPreferred` | boolean | true for the one fix the tool recommends, at most one per error |
| `applicability` | string | how safe it is to apply without review, see below |
| `diagnostics` | array of integers | indexes into the top-level `diagnostics` this fix resolves |
| `edit` | WorkspaceEdit or absent | text edits, LSP `WorkspaceEdit` with `changes` only |
| `command` | Command or absent | run the tool again with other options, or run another command |
| `result` | object or absent | what the tool measured for this fix without applying it (for example the size a layout gives), so the caller can choose without trying |

A CodeAction has `edit`, `command`, or both (apply the edit, then run the
command).

**`edit.changes`** maps a document to LSP `TextEdit`s
(`{ "range", "newText" }`). The document key is the `file` path; for a
diagram passed as a string it is `diagram:<n>` and ranges count within
that diagram. Edits for one document never overlap; apply them from the
last to the first so earlier positions stay valid.

**`command`**:

```json
{ "args": ["--max-width", "1213"], "api": { "max_width": 1213 } }
```

| Field | Type | Meaning |
|---|---|---|
| `args` | array of strings | command-line options to add or replace in the failed command; or, when `argv` is set, the whole command |
| `argv` | boolean | true when `args` is a complete command to run (for example `["npm", "run", "sync-mermaid", "--", "12.3.0"]`) |
| `api` | object | the same change as library API options (for example `{ "maxWidth": 1213 }` for `render()`), when the fix applies to an API call |

**`applicability`** (from rustc `suggestion_applicability`):

| Value | Meaning | Agent behaviour |
|---|---|---|
| `machine-applicable` | the fix is what is meant; applying it gives a valid result | may apply automatically |
| `maybe-incorrect` | likely right, but changes meaning or looks (another icon name, another layout) | apply only if the change is acceptable; check `result` and `title` |
| `has-placeholders` | contains `<...>` placeholders that must be filled in (for example `<path to Icon-package_*.zip>`) | fill in the placeholders, never pass them literally |
| `unspecified` | the tool cannot judge | review before applying |

Placeholders are written as `<` description `>` inside `newText` or
`args`.

### Positions

`range` and `TextEdit.range` use LSP positions:

- `line` is **0-based**. In text output, lines are shown 1-based
  (`docs/arch.md:7` is `line: 6`).
- `character` is a 0-based offset in UTF-16 code units, as in LSP's
  default encoding.
- The tools only report whole lines: `start.character` is 0 and `end` is
  the end of the last line (its length), so a client that cannot count
  UTF-16 can replace whole lines.
- Inserting lines is an edit with an empty range at the start of a line
  and `newText` ending in `\n`.
- Positions refer to the file as it was read, including any front matter.
  For a ` ```mermaid ` block, they are file lines, not lines inside the
  block.

## Text form

The default form, for people. It follows rustc / Ruff style:

```
render: error[too-wide]: diagram 1 is 1819px wide; shrinking it to --max-width 1000 would draw 48px icons at 26px, below --min-icon-size 32.
  --> docs/arch.md:7
   = natural width 1819px; at --max-width 1000 its 48px icons are drawn at 26px
   | flowchart LR
help: Change "flowchart LR" to "flowchart TB" (lay out top to bottom): 544x1879px, icons 48px [maybe-incorrect, preferred]
   | docs/arch.md:7
   | - flowchart LR
   | + flowchart TB
help: Allow a wider image: --max-width 1213 [machine-applicable]
   | --max-width 1213
help: Accept smaller icons: --min-icon-size 26 [machine-applicable]
   | --min-icon-size 26
```

- First line: `<tool>: error[<code>]: <message>`.
- ` --> file:line` for each diagnostic (1-based lines), then `   = ` with the
  diagnostic's own message (and `   = mermaid: ` with Mermaid's message,
  if any) and `   | ` with the line text.
- One `help:` block per CodeAction, in order, with its applicability. Edits
  are shown as `-` / `+` lines; commands as their arguments.

The text form is for reading; tools should use `--error-format json`.

## Library API

Library functions and methods (`Renderer.render`, `renderDiagrams`,
`packForNames`, ...) throw `BuildError` with:

| Property | Meaning |
|---|---|
| `code` | the error code |
| `message` | the message |
| `diagnostics` | list of diagnostics |
| `codeActions` | list of code actions |
| `toJSON(tool)` | the JSON form above as an object |
| `text()` | the text form without the tool prefix |

For diagrams passed as strings, diagnostics have `file: null` and
positions within the diagram. Pass `{ text, file, line }` objects to get
file positions; `diagramsInFile` and `mermaidBlocks` return them.

## Error codes

Codes are stable within a format version. New codes may be added; a
client must handle an unknown code (show `message`, apply nothing).

| Code | Tool | Meaning | Fixes offered |
|---|---|---|---|
| `usage` | all | command line could not be parsed | none; see `--help` |
| `file-not-found` | all | an input file does not exist | none |
| `unsupported-file-type` | build_iconpack, render | input is not `.md`, `.markdown`, `.mmd`, `.mermaid` | none |
| `unclosed-mermaid-block` | build_iconpack, render, make_example_html | a ` ```mermaid ` block has no closing fence | edit: insert the closing fence before the next heading or at the end (`maybe-incorrect`) |
| `no-mermaid-block` | render, make_example_html | a Markdown file has no ` ```mermaid ` block | none |
| `missing-heading` | make_example_html | no `# ` heading for the page title | edit: insert `# <title>` at line 1 (`has-placeholders`) |
| `icons-zip-missing` | render, make_example_html | diagrams use `aws:` icons but no icon zip was given | command: the failed command with `--icons-zip <path to Icon-package_*.zip>` (`has-placeholders`) |
| `icon-zip-not-found` | all that read the zip | the zip path does not exist | none (download it; the message gives the URL) |
| `bad-icon-zip` | same | the file is not a readable zip | none |
| `not-icon-package` | same | the zip is not the AWS icon package | none |
| `no-icons-of-size` | build_iconpack | no icons of the `--size` asked for | command: `--size <n>` for each size present, nearest first (`machine-applicable`) |
| `icon-name-collision` | build_iconpack | two icons map to one name | none (report to maintainers) |
| `no-icon-references` | build_iconpack | `--from` files use no `aws:` icons | none |
| `unknown-icon` | build_iconpack, render, make_example_html | a diagram uses an icon name not in the zip | edit per line: replace with the closest name (`maybe-incorrect`); diagnostic only when nothing is close |
| `missing-output` | build_iconpack | no `-o` and no `--list` | command: `-o aws.json`; command: `--list` (`machine-applicable`) |
| `bad-argument` | render, sync_mermaid | a value is out of range (`--scale`, `--max-width`, `--min-icon-size`, `--format`; a version that is not x.y.z) | render: command with a valid value (`machine-applicable`); sync_mermaid: none |
| `render-failed` | render, make_example_html | Mermaid could not parse or draw a diagram | diagnostic at the line Mermaid names, with Mermaid's message in `data.mermaid`; no automatic edit |
| `page-error` | render, make_example_html | the page reported an error while drawing | as `render-failed` |
| `unknown-icon-placeholder` | render, make_example_html | a drawing shows Mermaid's unknown-icon placeholder (an icon prefix with no pack) | diagnostic per line using an unregistered prefix |
| `too-wide` | render | `--max-width` would shrink an icon below `--min-icon-size` | edits: alternative layouts the tool rendered and measured, with `result` (`maybe-incorrect`); command: the smallest `--max-width` that works; command: a lower `--min-icon-size` (`machine-applicable`) |
| `node-missing` | render, make_example_html `--static` | Node.js is not on PATH | none (install Node.js, `npm install`) |
| `chrome-missing` | render, make_example_html `--static` | no chrome-headless-shell: the one set by `--chrome`, `CHROME_PATH` or `PUPPETEER_EXECUTABLE_PATH` is not a file, or none is set and puppeteer's cache (`$PUPPETEER_CACHE_DIR` or `~/.cache/puppeteer`) has no chrome-headless-shell of the version puppeteer-core expects; the message names that version and the cache path | command: `npx @puppeteer/browsers install chrome-headless-shell@<expected version> --path <cache path>` with both filled in (`machine-applicable`, preferred; the next run finds it); command: `--chrome <path to chrome-headless-shell>` (`has-placeholders`) |
| `chrome-launch-failed` | render, make_example_html `--static` | the browser at the given path did not start in `headless: 'shell'` mode (for example it is not a browser executable, or not built for this machine) | as `chrome-missing` |
| `render-timeout` | same | drawing did not finish in time | none |
| `vendor-missing` | render, make_example_html, sync_mermaid | the `mermaid` npm package is not installed (Font Awesome: `vendor/fontawesome/` has no version) | command: `npm ci` (`machine-applicable`, preferred); command: `npm install --save-exact mermaid@<version>` with the pinned version filled in (`machine-applicable`) |
| `vendor-mismatch` | render, make_example_html, sync_mermaid | the installed `mermaid` is another version, or a file used differs from the sha256 in `src/mermaid-manifest.json`; sync_mermaid also: `package.json` depends on another version (Font Awesome: a vendored file differs from its `MANIFEST.json`) | as `vendor-missing`; for another version, `npm install --save-exact mermaid@<version>` is preferred |
| `vendor-multiple` | render, make_example_html | more than one version under `vendor/fontawesome/` | none (keep one) |
| `download-failed` | sync_mermaid | the npm registry or tarball could not be fetched or verified | none |
| `internal` | all | a bug in mermaid-arch | none (report it) |

## Compatibility

- `version` changes only for incompatible changes (a field removed or its
  meaning changed).
- Within a version, fields, codes and `applicability` values may be
  added. Clients must ignore unknown fields and treat unknown
  `applicability` values as `unspecified`.

## References

- LSP 3.17 specification: Diagnostic, CodeAction, WorkspaceEdit, TextEdit, Position
- rustc JSON output: https://doc.rust-lang.org/rustc/json.html (`suggestion_applicability`)
- SARIF 2.1.0 (OASIS), considered and not used
