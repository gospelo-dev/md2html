# エラーの出力形式

状態: 第 1 版 (案)

英語版: [error-format.md](error-format.md)。2 つの内容が食い違うときは、英語版を正とします。

mermaid-arch のスクリプトは、人も AI エージェントも使います。実行に失敗したときは、何が悪いか、どこが悪いか、どう直すかを、どちらにも扱える形で伝えます。このドキュメントは、その形を定めます。

CLI のエラーと直し方を伝えるための、決まった標準はありません。そこで、すでにある形式から、合う部分を使います。

- **LSP** (Language Server Protocol 3.17) の `Diagnostic` と `CodeAction`: 「何がどこで悪いか」と「どう直すか」に使います。
- **rustc** の JSON 出力: 直し方の案がどれだけ確かか (`suggestion_applicability`) に使います。LSP にはこの項目がありません。

SARIF 2.1.0 も考えましたが、使いません。SARIF は静的解析の結果をたくさん集めるための形式で、1 回の実行がなぜ失敗したかを伝えるには向きません。

## 対象

次のスクリプトが対象です。

| コマンド | JSON の `tool` | 役割 |
|---|---|---|
| `mermaid-arch build-iconpack` | `build_iconpack` | AWS のアイコンの zip からアイコンパックを作る |
| `mermaid-arch render` | `render` | 図を PNG や SVG にする |
| `npm run make-example-html` (開発用) | `make_example_html` | サンプルの HTML を作る |
| `npm run sync-mermaid` (開発用) | `sync_mermaid` | Mermaid の版を固定する (`src/mermaid-manifest.json`)、インストールされた `mermaid` パッケージを確かめる |

ライブラリの API (`BuildError`、後述) も対象です。コマンドを選ぶ前の使い方の誤り (コマンドがない、知らないコマンド) は、`tool` を `mermaid-arch` として出します。

## 出す場所と終了コード

- 結果 (書き出したファイル名、`--list` の出力) は stdout に出すか、ファイルに書きます。エラーは **stderr** に出します。
- `--error-format text` (既定) では、文の形で出します。`--error-format json` では、stderr に **JSON のオブジェクトを 1 つだけ** 出し、最後に改行を付けます。ほかには何も出しません。
- 終了コードは次のとおりです。

| コード | 意味 |
|---|---|
| 0 | 成功 |
| 1 | 失敗した。エラーを出した |
| 2 | コマンドラインを解釈できなかった (使い方の誤り)。`--error-format json` のときは、これもコード `usage` の JSON で出す |

最初のエラーで止まります。1 つのエラーが、いくつもの diagnostic を持つことがあります (たとえば、知らないアイコン名を使っている行のすべて)。

## JSON の形

```json
{
  "version": 1,
  "tool": "render",
  "error": "too-wide",
  "message": "diagram 1 is 1819px wide; shrinking it to --max-width 1000 would draw 48px icons at 26px, below --min-icon-size 32.",
  "diagnostics": [ Diagnostic, ... ],
  "codeActions": [ CodeAction, ... ]
}
```

| 項目 | 型 | 意味 |
|---|---|---|
| `version` | 整数 | この形式の版。このドキュメントは第 1 版 |
| `tool` | 文字列 | エラーを出したスクリプト: `build_iconpack`、`render`、`make_example_html`、`sync_mermaid` |
| `error` | 文字列 | エラーコード ([エラーコード](#エラーコード) を参照)。変わらない値で、kebab-case |
| `message` | 文字列 | 何が悪いか。英語の文 1 つ以上 |
| `diagnostics` | 配列 | エラーに関わる場所。空のこともある (ファイルがないときなど) |
| `codeActions` | 配列 | 直し方。よいものから順に並べる。直し方がわからないときは空 |

メッセージ (`message`、`title` など) は英語で出します。

### Diagnostic

LSP の `Diagnostic` に合わせます。ただし、対象の文書は URI ではなく、`file` と `diagram` で示します。

```json
{
  "file": "docs/arch.md",
  "diagram": 1,
  "range": { "start": { "line": 6, "character": 0 }, "end": { "line": 6, "character": 12 } },
  "severity": "error",
  "code": "too-wide",
  "source": "mermaid-arch",
  "message": "this diagram is laid out left to right",
  "lineText": "flowchart LR",
  "data": { "naturalWidth": 1819 }
}
```

| 項目 | 型 | 意味 |
|---|---|---|
| `file` | 文字列か null | コマンドに渡されたままのパス。図を文字列で渡したとき (ライブラリの API) は null |
| `diagram` | 整数か null | 入力の中で何番目の図 (```` ```mermaid ```` ブロック) か。1 から数える。図に関わるエラーのときに付く |
| `range` | Range か null | LSP の Range。[位置](#位置) を参照。文の中の位置がないエラーでは null |
| `severity` | 文字列 | `error`。エラーに関わる補足の場所には `info` |
| `code` | 文字列 | エラーコード。主な diagnostic では、上の `error` と同じ |
| `source` | 文字列 | 常に `mermaid-arch` |
| `message` | 文字列 | この場所で何が悪いか |
| `lineText` | 文字列 | `range` の最初の行の、行全体の文字 (便利のため。LSP にはない) |
| `data` | オブジェクト | ツールごとの詳しい情報 (なくてもよい)。たとえば Mermaid のパーサーのメッセージを `mermaid` に入れる |

### CodeAction

LSP の `CodeAction` (`title`、`kind`、`isPreferred`、`edit`) に合わせます。それに、rustc から借りた `applicability` と、ファイルの書き換えではない直し方のための `command` と `result` を加えます。

```json
{
  "title": "Change \"flowchart LR\" to \"flowchart TB\" (544px wide, icons stay 48px)",
  "kind": "quickfix",
  "isPreferred": true,
  "applicability": "maybe-incorrect",
  "diagnostics": [0],
  "edit": {
    "changes": {
      "docs/arch.md": [
        { "range": { "start": { "line": 6, "character": 0 }, "end": { "line": 6, "character": 12 } },
          "newText": "flowchart TB" }
      ]
    }
  },
  "result": { "width": 544, "height": 1879, "iconPx": 48, "fits": true }
}
```

| 項目 | 型 | 意味 |
|---|---|---|
| `title` | 文字列 | 何をする直し方か。1 行 |
| `kind` | 文字列 | `quickfix` (LSP の kind) |
| `isPreferred` | 真偽値 | ツールが勧める直し方なら true。1 つのエラーで多くて 1 つ |
| `applicability` | 文字列 | 見直さずに当ててよいか。下の表を参照 |
| `diagnostics` | 整数の配列 | この直し方で解ける diagnostic の、上の `diagnostics` での番号 |
| `edit` | WorkspaceEdit (ないこともある) | 文字の書き換え。LSP の `WorkspaceEdit` で、`changes` だけを使う |
| `command` | Command (ないこともある) | オプションを変えて実行し直す、または別のコマンドを実行する |
| `result` | オブジェクト (ないこともある) | この直し方を当てずに、ツールが測った結果 (たとえば、別の配置にしたときの大きさ)。使う側は、試さずに直し方を選べる |

CodeAction は、`edit` と `command` のどちらか、または両方を持ちます。両方あるときは、書き換えてからコマンドを実行します。

**`edit.changes`** は、文書ごとに LSP の `TextEdit` (`{ "range", "newText" }`) の並びを持ちます。文書のキーは `file` のパスです。図を文字列で渡したときは `diagram:<n>` で、範囲はその図の中で数えます。1 つの文書の中で、書き換えの範囲は重なりません。後ろの書き換えから先に当てると、前の位置がずれません。

**`command`**:

```json
{ "args": ["--max-width", "1213"], "api": { "max_width": 1213 } }
```

| 項目 | 型 | 意味 |
|---|---|---|
| `args` | 文字列の配列 | 失敗したコマンドに足す、または置き換えるオプション。`argv` が true のときは、コマンド全体 |
| `argv` | 真偽値 | `args` がそのまま実行するコマンド全体のとき true (たとえば `["npm", "run", "sync-mermaid", "--", "12.3.0"]`) |
| `api` | オブジェクト | 同じ変更を、ライブラリの API のオプションで表したもの (たとえば `render()` の `{ "maxWidth": 1213 }`)。API の呼び出しに当てはまるときに付く |

**`applicability`** (rustc の `suggestion_applicability` から):

| 値 | 意味 | エージェントの扱い |
|---|---|---|
| `machine-applicable` | 意図どおりの直し方で、当てれば正しい結果になる | 自動で当ててよい |
| `maybe-incorrect` | たぶん正しいが、意味や見た目が変わる (別のアイコン名、別の配置) | その変更でよいときだけ当てる。`result` と `title` を確かめる |
| `has-placeholders` | 埋める必要がある `<...>` を含む (たとえば `<path to Icon-package_*.zip>`) | 埋めてから使う。そのまま渡してはいけない |
| `unspecified` | ツールには判断できない | 当てる前に見直す |

埋める箇所は、`newText` や `args` の中に `<` 説明 `>` の形で書きます。

### 位置

`range` と `TextEdit.range` は、LSP の位置を使います。

- `line` は **0 から** 数えます。文の出力では 1 から数えて示します (`docs/arch.md:7` は `line: 6`)。
- `character` は、LSP の既定と同じく、UTF-16 のコード単位で 0 から数えた位置です。
- ツールは常に行全体を指します。`start.character` は 0 で、`end` は最後の行の終わり (その行の長さ) です。UTF-16 で数えられないクライアントでも、行を丸ごと置き換えれば直せます。
- 行を差し込むときは、行の先頭の空の範囲に、`\n` で終わる `newText` を書き込みます。
- 位置は、読んだときのファイルのままで数えます。front matter も含みます。```` ```mermaid ```` ブロックでも、ブロックの中の行番号ではなく、ファイルの行番号で示します。

## 文の形

既定の形で、人が読むためのものです。rustc や Ruff の書き方に合わせます。

```
render: error[too-wide]: diagram 1 is 1819px wide; shrinking it to --max-width 1000 would draw 48px icons at 26px, below --min-icon-size 32.
  --> docs/arch.md:7
   = natural width 1819px; at --max-width 1000 its 48px icons are drawn at 26px
   | flowchart LR
help: Change "flowchart LR" to "flowchart TB" (lay out top to bottom): 544x1879px, icons 48px [maybe-incorrect, preferred]
   | docs/arch.md:7
   | - flowchart LR
   | + flowchart TB
help: Allow a wider image: --max-width 1213 [machine-applicable]
   | --max-width 1213
help: Accept smaller icons: --min-icon-size 26 [machine-applicable]
   | --min-icon-size 26
```

- 1 行目: `<tool>: error[<code>]: <message>`。
- diagnostic ごとに、` --> file:line` (1 から数えた行)。続けて、`   = ` でその diagnostic のメッセージ (Mermaid のメッセージがあれば `   = mermaid: `)、`   | ` でその行の文字。
- CodeAction ごとに、順に `help:` を 1 つ。確かさも付けます。書き換えは `-` と `+` の行で、コマンドは引数で示します。

文の形は読むためのものです。ツールから使うときは `--error-format json` を使ってください。

## ライブラリの API

ライブラリの関数とメソッド (`Renderer.render`、`renderDiagrams`、`packForNames` など) は、次のプロパティを持つ `BuildError` を投げます。

| プロパティ | 意味 |
|---|---|
| `code` | エラーコード |
| `message` | メッセージ |
| `diagnostics` | diagnostic の並び |
| `codeActions` | code action の並び |
| `toJSON(tool)` | 上の JSON の形をオブジェクトで返す |
| `text()` | 文の形。ツール名は付かない |

図を文字列で渡したときは、diagnostic の `file` は null で、位置はその図の中で数えます。ファイルの位置がほしいときは、`{ text, file, line }` の形で渡してください。`diagramsInFile` と `mermaidBlocks` はこの形で返します。

## エラーコード

エラーコードは、同じ版の中では変わりません。新しいコードが増えることはあります。使う側は、知らないコードを受け取ったら、`message` を示し、何も当てないでください。

| コード | ツール | 意味 | 出す直し方 |
|---|---|---|---|
| `usage` | すべて | コマンドラインを解釈できない | なし。`--help` を見る |
| `file-not-found` | すべて | 入力のファイルがない | なし |
| `unsupported-file-type` | build_iconpack、render | 入力が `.md`、`.markdown`、`.mmd`、`.mermaid` のどれでもない | なし |
| `unclosed-mermaid-block` | build_iconpack、render、make_example_html | ```` ```mermaid ```` ブロックを閉じる行がない | edit: 次の見出しの前か、ファイルの最後に、閉じる行を差し込む (`maybe-incorrect`) |
| `no-mermaid-block` | render、make_example_html | md に ```` ```mermaid ```` ブロックがない | なし |
| `missing-heading` | make_example_html | ページのタイトルにする `# ` 見出しがない | edit: 1 行目に `# <title>` を差し込む (`has-placeholders`) |
| `icons-zip-missing` | render、make_example_html | 図が `aws:` のアイコンを使っているのに、zip が渡されていない | command: 失敗したコマンドに `--icons-zip <path to Icon-package_*.zip>` を足したもの (`has-placeholders`) |
| `icon-zip-not-found` | zip を読むすべて | zip のパスにファイルがない | なし (ダウンロードする。メッセージに URL を示す) |
| `bad-icon-zip` | 同上 | ファイルが読める zip ではない | なし |
| `not-icon-package` | 同上 | zip が AWS のアイコンパッケージではない | なし |
| `no-icons-of-size` | build_iconpack | `--size` で指定した大きさのアイコンがない | command: zip にある大きさごとの `--size <n>`。近い順 (`machine-applicable`) |
| `icon-name-collision` | build_iconpack | 2 つのアイコンが同じ名前になる | なし (保守する人に知らせる) |
| `no-icon-references` | build_iconpack | `--from` のファイルが `aws:` のアイコンを使っていない | なし |
| `unknown-icon` | build_iconpack、render、make_example_html | 図が、zip にないアイコン名を使っている | 行ごとの edit: いちばん近い名前に置き換える (`maybe-incorrect`)。近い名前がないときは diagnostic だけ |
| `missing-output` | build_iconpack | `-o` も `--list` もない | command: `-o aws.json`、command: `--list` (`machine-applicable`) |
| `bad-argument` | render、sync_mermaid | 値が範囲の外 (`--scale`、`--max-width`、`--min-icon-size`、`--format`。x.y.z の形でない版) | render: 正しい値の command (`machine-applicable`)。sync_mermaid: なし |
| `render-failed` | render、make_example_html | Mermaid が図を解釈できない、または描けない | Mermaid が示した行の diagnostic。Mermaid のメッセージは `data.mermaid` に入れる。自動の書き換えはなし |
| `page-error` | render、make_example_html | 描いている間に、ページがエラーを出した | `render-failed` と同じ |
| `unknown-icon-placeholder` | render、make_example_html | 描いた図に、Mermaid の仮のアイコンが出た (パックのない接頭辞を使っている) | 登録されていない接頭辞を使っている行ごとの diagnostic |
| `too-wide` | render | `--max-width` で縮めると、アイコンが `--min-icon-size` より小さくなる | edit: ツールが実際に描いて測った別の配置。`result` 付き (`maybe-incorrect`)。command: 収まるいちばん小さい `--max-width`。command: もっと小さい `--min-icon-size` (`machine-applicable`) |
| `node-missing` | render、make_example_html `--static` | PATH に Node.js がない | なし (Node.js を入れ、`npm install` する) |
| `chrome-missing` | render、make_example_html `--static` | chrome-headless-shell がない。`--chrome`、`CHROME_PATH`、`PUPPETEER_EXECUTABLE_PATH` で指定した先がファイルでない、またはどれも指定されておらず、puppeteer のキャッシュ (`$PUPPETEER_CACHE_DIR`、なければ `~/.cache/puppeteer`) に puppeteer-core が想定する版の chrome-headless-shell がない。メッセージに、その版とキャッシュのパスを入れる | command: 版とキャッシュのパスを埋めた `npx @puppeteer/browsers install chrome-headless-shell@<想定の版> --path <キャッシュのパス>` (`machine-applicable`、勧める案。次の実行で見つかる)。command: `--chrome <path to chrome-headless-shell>` (`has-placeholders`) |
| `chrome-launch-failed` | render、make_example_html `--static` | 指定したパスのブラウザが `headless: 'shell'` で起動しなかった (ブラウザの実行ファイルでない、このマシン向けでない、など) | `chrome-missing` と同じ |
| `render-timeout` | 同上 | 決まった時間内に描き終わらなかった | なし |
| `vendor-missing` | render、make_example_html、sync_mermaid | npm の `mermaid` パッケージがインストールされていない (Font Awesome: `vendor/fontawesome/` に版がない) | command: `npm ci` (`machine-applicable`、優先)。command: 固定した版を埋めた `npm install --save-exact mermaid@<version>` (`machine-applicable`) |
| `vendor-mismatch` | render、make_example_html、sync_mermaid | インストールされた `mermaid` の版が違う、または使うファイルが `src/mermaid-manifest.json` の sha256 と合わない。sync_mermaid ではさらに、`package.json` の依存の版が違う (Font Awesome: vendor のファイルが `MANIFEST.json` と合わない) | `vendor-missing` と同じ。版が違うときは `npm install --save-exact mermaid@<version>` を優先 |
| `vendor-multiple` | render、make_example_html | `vendor/fontawesome/` に版が 2 つ以上ある | なし (1 つだけ残す) |
| `download-failed` | sync_mermaid | npm のレジストリや tarball を取ってこられない、または確かめられない | なし |
| `internal` | すべて | mermaid-arch の不具合 | なし (知らせる) |

## 互換性

- `version` は、互換性のない変更 (項目をなくす、意味を変える) のときだけ変えます。
- 同じ版の中で、項目、エラーコード、`applicability` の値が増えることがあります。使う側は、知らない項目を無視し、知らない `applicability` の値を `unspecified` として扱ってください。

## 参考

- LSP 3.17 の仕様: Diagnostic、CodeAction、WorkspaceEdit、TextEdit、Position
- rustc の JSON 出力: https://doc.rust-lang.org/rustc/json.html (`suggestion_applicability`)
- SARIF 2.1.0 (OASIS): 検討したが使わない
