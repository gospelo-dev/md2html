/*
 * mermaid-arch.js
 * Copyright (c) 2026 gospelo-dev
 * SPDX-License-Identifier: MIT
 *
 * Small helper loaded after the official Mermaid single-file build
 * (dist/mermaid.min.js of the mermaid npm package). It does not contain Mermaid.
 *
 *   <script src="mermaid.min.js"></script>
 *   <script src="mermaid-arch.js"></script>
 *   <script>
 *     mermaidArch.setup({ iconPacks: [awsPackJson], config: { theme: 'default' } })
 *     // then mermaid.run() or mermaid.render(...)
 *   </script>
 *
 * Mermaid 12 bundles the ELK layout and shares one icon registry between
 * the core renderer and ELK, so a single mermaid.registerIconPacks call is
 * enough for flowchart (with or without layout: elk) and architecture-beta.
 *
 * Icon packs use the Iconify JSON form: { "prefix": "aws", "icons": { ... } }.
 * The pack is registered under its own prefix (aws:lambda, ...).
 */
(function (global) {
  'use strict'

  function fail(msg) {
    throw new Error('mermaidArch: ' + msg)
  }

  function getMermaid() {
    var m = global.mermaid
    if (!m || typeof m.initialize !== 'function' || typeof m.registerIconPacks !== 'function') {
      fail('window.mermaid is not loaded. Fix: add <script src=".../mermaid.min.js"><\/script> ' +
        'before mermaid-arch.js')
    }
    return m
  }

  function toLoaders(packs) {
    if (!Array.isArray(packs)) fail('iconPacks must be an array. Fix: pass iconPacks: [pack] (Iconify JSON objects)')
    var seen = Object.create(null)
    return packs.map(function (pack, i) {
      var where = 'iconPacks[' + i + ']'
      if (!pack || typeof pack !== 'object') fail(where + ' is not an object. Fix: pass the parsed Iconify JSON ({ prefix, icons })')
      if (typeof pack.prefix !== 'string' || pack.prefix === '') fail(where + '.prefix is missing. Fix: pass an Iconify JSON pack with a "prefix" such as "aws"')
      if (!pack.icons || typeof pack.icons !== 'object' || Object.keys(pack.icons).length === 0) {
        fail(where + ' ("' + pack.prefix + '") has no icons. Fix: build the pack with ' +
          'mermaid-arch build-iconpack, or leave out packs that are not needed')
      }
      if (seen[pack.prefix]) fail('icon pack prefix "' + pack.prefix + '" is given more than once. ' +
        'Fix: pass each prefix once; merge the icons into one pack if needed')
      seen[pack.prefix] = true
      return { name: pack.prefix, icons: pack }
    })
  }

  /**
   * Register icon packs and initialize Mermaid.
   *
   * @param {object} options
   * @param {object[]} [options.iconPacks]  Iconify JSON packs
   * @param {object}   [options.config]     passed to mermaid.initialize;
   *                                        startOnLoad defaults to false
   * @returns the mermaid object
   */
  function setup(options) {
    var opts = options || {}
    var mermaid = getMermaid()
    if (opts.iconPacks !== undefined) {
      var loaders = toLoaders(opts.iconPacks)
      if (loaders.length > 0) mermaid.registerIconPacks(loaders)
    }
    var config = Object.assign({ startOnLoad: false }, opts.config || {})
    mermaid.initialize(config)
    return mermaid
  }

  global.mermaidArch = Object.freeze({ setup: setup })
})(typeof window !== 'undefined' ? window : globalThis)
